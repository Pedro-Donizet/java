import models.Carro;
import models.Frota;
import models.Moto;
import models.Veiculo;

import java.util.ArrayList;
import java.util.Scanner;

import static services.VeicleServices.CadastrarCarro;
import static services.VeicleServices.CadastrarMoto;

public class Main {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        AbrirMenuPrincipal();
    }

    public static void AbrirMenuPrincipal() {
        var veiculos = new ArrayList<Veiculo>();
        var frota = new Frota();


        var continuar = true;
        while (continuar) {
            System.out.println("Menu:");
            System.out.println("1. Cadastro de Carros");
            System.out.println("2. Cadastro de Motos");
            System.out.println("0. Sair");

            var opcao = scanner.nextInt();
            scanner.nextLine();

            if (opcao == 1) {
                var carro = CadastrarCarro();
                frota.getVeiculos().add(carro);
            }
            if (opcao == 2) {
                var moto = CadastrarMoto();
                frota.getVeiculos().add(moto);
            }
            if (opcao == 0) {
                continuar = false;
                break;
            }
        }
    }
}





package models;

import java.util.ArrayList;
import java.util.List;

public class Frota {
    private int numero;
    private List<Veiculo> veiculos = new ArrayList<Veiculo>();

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public List<Veiculo> getVeiculos() {
        return veiculos;
    }

    public void setVeiculos(List<Veiculo> veiculos) {
        this.veiculos = veiculos;
    }
}

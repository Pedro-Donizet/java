package veiculoTeste;

import models.Carro;
import models.Moto;

public class veiculoteste {

    public static void TestarApp()
    {
        TestarApp();

        var corola = new Carro("Toyota", "Corola", 2023,4);
        var mustang = new Carro("Ford", "Mustang", 2023,4);
        var ninja = new Moto("Kawasaki", "Ninja", 2023,"Esportiva");

        corola.Acelerar();
        corola.AbrirPortas();

        mustang.Acelerar();

        ninja.Acelerar();
        ninja.Empinar();
        System.out.println("==============Sistema ok e funcionando==============");
    }
}



package services;

import models.Carro;
import models.Moto;

import java.util.Scanner;

public class VeicleServices {
    private static Scanner scanner = new Scanner(System.in);


    public static Carro CadastrarCarro()
    {
        var novoCarro = new Carro();
        System.out.println("Marca: ");
        novoCarro.setMarca(scanner.nextLine());

        System.out.println("Modelo: ");
        novoCarro.setModelo(scanner.nextLine());

        System.out.println("Ano: ");
        novoCarro.setAno(scanner.nextInt());
        scanner.nextLine();

        System.out.println("Quantidade de Portas: ");
        novoCarro.setQuantidadeDePortas(scanner.nextInt());
        scanner.nextLine();

        System.out.println("models.Carro cadastrado: " + novoCarro.toString());
        return novoCarro;
    }

    public static Moto CadastrarMoto(){
        var novaMoto = new Moto();
        System.out.println("Marca: ");
        novaMoto.setMarca(scanner.nextLine());

        System.out.println("Modelo: ");
        novaMoto.setModelo(scanner.nextLine());

        System.out.println("Ano: ");
        novaMoto.setAno(scanner.nextInt());
        scanner.nextLine();

        System.out.println("Tipo: ");
        novaMoto.setTipo(scanner.nextLine());

        System.out.println("models.Moto cadastrada: " + novaMoto.toString());
        return novaMoto;
    }
}
